package org.esiea.arellano.sylla.library_project.model;

public class AndroidVersion {

    private String titre;
    private String auteur;
    private String edition;

    public String getTitre() {
        return titre;
    }

    public String getAuteur() {
        return auteur;
    }

    public String getEditorial() {
        return edition;
    }
}