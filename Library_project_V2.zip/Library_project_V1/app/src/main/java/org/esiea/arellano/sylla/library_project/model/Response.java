package org.esiea.arellano.sylla.library_project.model;

import java.util.ArrayList;
import java.util.List;

public class Response {

    private List<AndroidVersion> android = new ArrayList<AndroidVersion>();

    public List<AndroidVersion> getAndroid() {
        return android;
    }
}
